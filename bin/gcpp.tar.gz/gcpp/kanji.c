static char SccsId[] = "@(#)kanji.c	1.1 2/23/97 [MISCCSID]";
#ifndef _WIN32

int
is_kanji_leadbyte( c)
int c;
{
        int len;
        static unsigned char buf[3] = {0, 160, 0};
        buf[0] = c;
        return mblen((char *) buf, 2) == 2;
}
#else

#include <windows.h>

int
is_kanji_leadbyte(int c) {
        return IsDBCSLeadByte(c);
}
#endif
