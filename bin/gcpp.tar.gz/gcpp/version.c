static char SccsId[] = "@(#)version.c	1.1 1/23/97 [MISCCSID]";
char *version_string = "2.7.2";
